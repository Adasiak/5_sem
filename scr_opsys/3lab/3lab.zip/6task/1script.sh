echo -n "$$ "
while true 
do
    date >> fifo
    sleep 1
done
