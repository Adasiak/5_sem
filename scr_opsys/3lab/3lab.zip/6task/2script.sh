while true 
do 
    cat  fifo
    sleep 1
done 