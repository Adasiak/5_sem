sleep 10
echo "skrypt 7_1"