sleep 10
echo "skrypt 7_2"