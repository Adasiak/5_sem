nice -n 20 -u ./7_1task.sh
nice -n 5 -u ./7_2task.sh