while true
do    
    echo "1script"
    ./1script.sh
done